<!DOCTYPE html>
<html>
<head>
    <title>نمایش وقت های رزرو شده</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <h2>وقت های رزرو شده</h2>

    <table>
        <tr>
            <th>نام بیمار</th>
            <th>تاریخ</th>
            <th>زمان</th>
        </tr>
        <?php
        // اتصال به پایگاه داده
        $servername = "نام_سرور";
        $username = "نام_کاربری";
        $password = "رمز_عبور";
        $dbname = "نام_پایگاه_داده";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // بررسی اتصال
        if ($conn->connect_error) {
            die("اتصال به پایگاه داده با خطا مواجه شد: " . $conn->connect_error);
        }

        // دریافت وقت های رزرو شده از پایگاه داده
        $sql = "SELECT نام_بیمار, تاریخ, زمان FROM جدول_رزرو";
        $result = $conn->query($sql);

        // نمایش وقت های رزرو شده
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row["نام_بیمار"]."</td>";
                echo "<td>".$row["تاریخ"]."</td>";
                echo "<td>".$row["زمان"]."</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>هیچ وقت رزرو شده ای وجود ندارد.</td></tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html>
