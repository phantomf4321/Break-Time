<?php
session_start();

if (isset($_SESSION["doctor"])) {
    // اتصال به پایگاه داده
    $servername = "localhost";
    $username = "نام_کاربری";
    $password = "رمز_عبور";
    $dbname = "نام_پایگاه_داده";

    // ایجاد اتصال
    $conn = new mysqli($servername, $username, $password, $dbname);

    // بررسی اتصال
    if ($conn->connect_error) {
        die("خطا در اتصال به پایگاه داده: " . $conn->connect_error);
    }

    // استعلام وقت‌های رزرو شده توسط مراجعین
    $sql = "SELECT * FROM appointments WHERE doctor_id = ?";
    $stmt = $conn->prepare($sql);
    $doctorId = $_SESSION["doctor_id"];
    $stmt->bind_param("i", $doctorId);
    $stmt->execute();
    $result = $stmt->get_result();
    $reservedAppointments = $result->fetch_all(MYSQLI_ASSOC);

    // استعلام وقت‌های موجود
    //  باید کوئری مناسب برای بازیابی وقت‌های موجود مثل SELECT استفاده کنم

    // نمایش وقت‌های رزرو شده توسط مراجعین
    echo "<h3>وقت‌های رزرو شده:</h3>";
    echo "<ul>";
    foreach ($reservedAppointments as $appointment) {
        echo "<li>" . $appointment["date"] . " - " . $appointment["time"] . "</li>";
    }
    echo "</ul>";

    // نمایش وقت‌های موجود
    echo "<h3>وقت‌های موجود:</h3>";
    // اینجا یک حلقه و کد مناسب برای نمایش وقت‌های موجود بیاد

    // قطع اتصال به پایگاه داده
    $conn->close();
} else {
    header("Location: login.php");
    exit();
}
?>
