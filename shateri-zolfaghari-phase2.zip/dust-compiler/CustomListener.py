from parser import DustListener
from parser import DustParser
from enum import Enum
from pprint import pprint


class ScopeType(Enum):
    PROGRAM = 0
    CLASS = 1
    METHOD = 2
    IF = 3
    WHILE = 4
    FOR = 5


class KeyPrinter(DustListener):
    indent_level = 0
    current_scope = -1
    previous_scope = -1
    scopes = []
    Defined = [
        "int",
        "bool",
        "string",
        "float",
    ]

    def print(self, message, **kwargs):
        for _ in range(self.indent_level):
            print("\t", end="")
        print(message, **kwargs)

    def getScope(self):
        return self.scopes[self.current_scope]

    def newScope(self, line: int, name: ScopeType, type: ScopeType):
        ns = {}
        ns["line"] = line
        ns["name"] = name
        ns["type"] = type
        self.scopes.append(ns)
        self.previous_scope = self.current_scope
        self.current_scope = len(self.scopes) - 1

    def restoreScope(self):
        self.current_scope, self.previous_scope = (
            self.previous_scope,
            self.current_scope,
        )

    def printScope(self):
        # pprint(self.scopes)
        # return
        for scope in self.scopes:
            print("---------- {} : {} ----------".format(scope["name"], scope["line"]))
            for key in scope:
                if key == "name" or key == "line" or key == "type":
                    continue
                print("Key: {} | Value: {}".format(key, scope[key]))

    def indent(self):
        self.indent_level += 1

    def unindent(self):
        self.indent_level -= 1

    def enterProgram(self, ctx: DustParser.ProgramContext):
        self.newScope(ctx.start.line, "program", ScopeType.PROGRAM)

    # Exit a parse tree produced by DustParser#program.
    def exitProgram(self, ctx: DustParser.ProgramContext):
        self.restoreScope()

    # Enter a parse tree produced by DustParser#importclass.
    def enterImportclass(self, ctx: DustParser.ImportclassContext):
        className = ctx.getChild(1).getText()
        self.Defined.append(className)
        # self.print("import class: {}".format(className))

    # Enter a parse tree produced by DustParser#classDef.
    def enterClassDef(self, ctx: DustParser.ClassDefContext):
        className = ctx.getChild(1).getText()
        # self.print("class: {}/ class parents: ".format(className), end="")
        parents = ""
        if ctx.getChild(2).getText() == "(":
            i = 3
            while ctx.getChild(i).getText() != ")":
                parents += ctx.getChild(i).getText()
                i += 1
        parents = parents.split(",")

        # for p in parents.split(","):
        #     print("{}, ".format(p), end="")

        # print("objects, {")
        # self.indent()
        scope = self.getScope()
        key = "Class_{}".format(className)
        value = "Class (name {})".format(className)
        if len(parents) > 0:
            value += "(parent:"
            for p in parents:
                value += p + ","
            value += ")"

        scope[key] = value

        self.newScope(ctx.start.line, className, ScopeType.CLASS)

        # Add Class to Defined list
        self.Defined.append(ctx.getChild(1).getText())

    # Exit a parse tree produced by DustParser#classDef.
    def exitClassDef(self, ctx: DustParser.ClassDefContext):
        self.restoreScope()
        # self.unindent()
        # self.print("}")

    # Enter a parse tree produced by DustParser#varDec.
    def enterVarDec(self, ctx: DustParser.VarDecContext):
        # breakpoint()
        # self.print(
        #     "field: {}/ type={} ".format(
        #         ctx.getChild(1).getText(),
        #         ctx.getChild(0).getText(),
        #     )
        # )
        scope = self.getScope()
        key = "Field_{}".format(ctx.getChild(1).getText())
        value = ""
        if scope["type"] == ScopeType.CLASS:
            value += "ClassField "
        elif scope["type"] == ScopeType.METHOD:
            value += "MethodVar "
        elif (
            scope["type"] == ScopeType.WHILE
            or scope["type"] == ScopeType.FOR
            or scope["type"] == ScopeType.IF
        ):
            value += "LocalVar "

        value += "(name: {}) (type: {},ifDefined: {})".format(
            ctx.getChild(1).getText(),
            ctx.getChild(0).getText(),
            ctx.getChild(0).getText() in self.Defined,
        )

        scope[key] = value

    # Enter a parse tree produced by DustParser#arrayDec.
    def enterArrayDec(self, ctx: DustParser.ArrayDecContext):
        # self.print(
        #     "field: {}/ type={}".format(
        #         ctx.getChild(4).getText(), ctx.getChild(0).getText()
        #     )
        # )
        scope = self.getScope()
        key = "Field_{}".format(ctx.getChild(4).getText())
        value = ""
        if scope["type"] == ScopeType.CLASS:
            value += "ClassField "
        elif scope["type"] == ScopeType.METHOD:
            value += "MethodVar "
        elif (
            scope["type"] == ScopeType.WHILE
            or scope["type"] == ScopeType.FOR
            or scope["type"] == ScopeType.IF
        ):
            value += "LocalVar "

        value += "(name: {}) (type: {}[],ifDefined: {})".format(
            ctx.getChild(4).getText(),
            ctx.getChild(0).getText(),
            ctx.getChild(1).getText() in self.Defined,
        )

        scope[key] = value

    # Enter a parse tree produced by DustParser#methodDec.
    def enterMethodDec(self, ctx: DustParser.MethodDecContext):
        # breakpoint()
        # self.print(
        #     "class method: {}/ return type: {} ".format(
        #         ctx.getChild(2).getText(), ctx.getChild(1).getText()
        #     ),
        #     end="",
        # )
        # print("{")
        pl = []
        if ctx.getChild(4).getText() != ")":
            p = ctx.getChild(4)
            for pp in p.getChildren():
                if pp.getText() != ",":
                    pl.append(
                        "{} {}".format(
                            pp.getChild(0).getText(), pp.getChild(1).getText()
                        )
                    )

        # self.indent()
        # self.print("parameter list: {}".format(pl))
        scope = self.getScope()
        key = "Method_{}".format(ctx.getChild(2).getText())
        value = "Method (name: {}) (return type: {}) (parameter list: {})".format(
            ctx.getChild(2).getText(), ctx.getChild(1).getText(), pl
        )
        scope[key] = value
        self.newScope(ctx.start.line, ctx.getChild(2), ScopeType.METHOD)

    # Exit a parse tree produced by DustParser#methodDec.
    def exitMethodDec(self, ctx: DustParser.MethodDecContext):
        self.restoreScope()

    # Enter a parse tree produced by DustParser#constructor.
    def enterConstructor(self, ctx: DustParser.ConstructorContext):
        # self.print("class constructor {} ".format(ctx.getChild(1).getText()), end="")
        # print("{")
        pl = []
        if ctx.getChild(3).getText() != ")":
            p = ctx.getChild(3)
            for pp in p.getChildren():
                if pp.getText() != ",":
                    pl.append(
                        "{} {}".format(
                            pp.getChild(0).getText(), pp.getChild(1).getText()
                        )
                    )

        # self.indent()
        # self.print("parameter list: {}".format(pl))
        scope = self.getScope()
        key = "Constructor_{}".format(ctx.getChild(1).getText())
        value = "Constructor (name: {}) (return type: []) (parameter list: {})".format(
            ctx.getChild(1).getText(), pl
        )
        scope[key] = value
        self.newScope(ctx.start.line, ctx.getChild(1), ScopeType.METHOD)

    # Exit a parse tree produced by DustParser#constructor.
    def exitConstructor(self, ctx: DustParser.ConstructorContext):
        self.restoreScope()

    # Enter a parse tree produced by DustParser#condition_list.
    def enterCondition_list(self, ctx: DustParser.Condition_listContext):
        pass

    # Exit a parse tree produced by DustParser#condition_list.
    def exitCondition_list(self, ctx: DustParser.Condition_listContext):
        pass

    # Enter a parse tree produced by DustParser#condition.
    def enterCondition(self, ctx: DustParser.ConditionContext):
        pass

    # Exit a parse tree produced by DustParser#condition.
    def exitCondition(self, ctx: DustParser.ConditionContext):
        pass

    # Enter a parse tree produced by DustParser#if_statment.
    def enterIf_statment(self, ctx: DustParser.If_statmentContext):
        self.newScope(ctx.start.line, "if", ScopeType.IF)

    # Exit a parse tree produced by DustParser#if_statment.
    def exitIf_statment(self, ctx: DustParser.If_statmentContext):
        self.restoreScope()

    # Enter a parse tree produced by DustParser#while_statment.
    def enterWhile_statment(self, ctx: DustParser.While_statmentContext):
        self.newScope(ctx.start.line, "while", ScopeType.WHILE)

    # Exit a parse tree produced by DustParser#while_statment.
    def exitWhile_statment(self, ctx: DustParser.While_statmentContext):
        self.restoreScope()

    # Enter a parse tree produced by DustParser#if_else_statment.
    def enterIf_else_statment(self, ctx: DustParser.If_else_statmentContext):
        self.newScope(ctx.start.line, "if", ScopeType.IF)

    # Exit a parse tree produced by DustParser#if_else_statment.
    def exitIf_else_statment(self, ctx: DustParser.If_else_statmentContext):
        self.restoreScope()

    # Enter a parse tree produced by DustParser#print_statment.
    def enterPrint_statment(self, ctx: DustParser.Print_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#print_statment.
    def exitPrint_statment(self, ctx: DustParser.Print_statmentContext):
        pass

    # Enter a parse tree produced by DustParser#for_statment.
    def enterFor_statment(self, ctx: DustParser.For_statmentContext):
        self.newScope(ctx.start.line, "for", ScopeType.FOR)

    # Exit a parse tree produced by DustParser#for_statment.
    def exitFor_statment(self, ctx: DustParser.For_statmentContext):
        self.restoreScope()
