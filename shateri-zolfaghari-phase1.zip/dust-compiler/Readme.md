# مستندات پروژه کامپایلر زبان `Dust`
## راه اندازی محیط توسعه
این پروژه با زبان پایتون و با استفاده از کتابخانه `antlr` توسعه داده شده است.
نصب پیشنیازهای اجرا در آرچ لینوکس:
‍
```
sudo pacman -S antlr4 python-antl4
```

پروژه دارای دو پیشنیاز دیگر هم میباشد که تنها برای تجربه بهتر توسعه استفاده شده است و نصب آنها برای 
اجرای پروژه **اجباری نیست**.
```
sudo pacman -S black just
```

## راهنمای اجرای فاز یک
‍‍‍
```
python main.py examples/phase1.ds
```

در صورت نصب `just` با دستور زیر نیز میتوان فاز یک را اجرا نمود:

```
just phase1
```

### نحوه پیاده سازی فاز یک
کلاس `KeyPrinter` در فایل `CustomListener.py` با ارث بری از کلاس `DustListener` که توسط 
انتلر ساخته شده است و `overwrite` کردن توابع زیر موارد خواسته شده را چاپ میکند.
```
enterProgram
exitProgram
enterImportClass
enterClassDef
exitClassDef
enterVarDec
enterArrayDec
enterMethodDec
exitMethodDec
enterConstructor
exitConstructor
```
