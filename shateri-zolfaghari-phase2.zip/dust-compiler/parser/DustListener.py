# Generated from Dust.g4 by ANTLR 4.12.0
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .DustParser import DustParser
else:
    from DustParser import DustParser

# This class defines a complete listener for a parse tree produced by DustParser.
class DustListener(ParseTreeListener):

    # Enter a parse tree produced by DustParser#program.
    def enterProgram(self, ctx:DustParser.ProgramContext):
        pass

    # Exit a parse tree produced by DustParser#program.
    def exitProgram(self, ctx:DustParser.ProgramContext):
        pass


    # Enter a parse tree produced by DustParser#importclass.
    def enterImportclass(self, ctx:DustParser.ImportclassContext):
        pass

    # Exit a parse tree produced by DustParser#importclass.
    def exitImportclass(self, ctx:DustParser.ImportclassContext):
        pass


    # Enter a parse tree produced by DustParser#classDef.
    def enterClassDef(self, ctx:DustParser.ClassDefContext):
        pass

    # Exit a parse tree produced by DustParser#classDef.
    def exitClassDef(self, ctx:DustParser.ClassDefContext):
        pass


    # Enter a parse tree produced by DustParser#class_body.
    def enterClass_body(self, ctx:DustParser.Class_bodyContext):
        pass

    # Exit a parse tree produced by DustParser#class_body.
    def exitClass_body(self, ctx:DustParser.Class_bodyContext):
        pass


    # Enter a parse tree produced by DustParser#varDec.
    def enterVarDec(self, ctx:DustParser.VarDecContext):
        pass

    # Exit a parse tree produced by DustParser#varDec.
    def exitVarDec(self, ctx:DustParser.VarDecContext):
        pass


    # Enter a parse tree produced by DustParser#arrayDec.
    def enterArrayDec(self, ctx:DustParser.ArrayDecContext):
        pass

    # Exit a parse tree produced by DustParser#arrayDec.
    def exitArrayDec(self, ctx:DustParser.ArrayDecContext):
        pass


    # Enter a parse tree produced by DustParser#methodDec.
    def enterMethodDec(self, ctx:DustParser.MethodDecContext):
        pass

    # Exit a parse tree produced by DustParser#methodDec.
    def exitMethodDec(self, ctx:DustParser.MethodDecContext):
        pass


    # Enter a parse tree produced by DustParser#constructor.
    def enterConstructor(self, ctx:DustParser.ConstructorContext):
        pass

    # Exit a parse tree produced by DustParser#constructor.
    def exitConstructor(self, ctx:DustParser.ConstructorContext):
        pass


    # Enter a parse tree produced by DustParser#parameter.
    def enterParameter(self, ctx:DustParser.ParameterContext):
        pass

    # Exit a parse tree produced by DustParser#parameter.
    def exitParameter(self, ctx:DustParser.ParameterContext):
        pass


    # Enter a parse tree produced by DustParser#statement.
    def enterStatement(self, ctx:DustParser.StatementContext):
        pass

    # Exit a parse tree produced by DustParser#statement.
    def exitStatement(self, ctx:DustParser.StatementContext):
        pass


    # Enter a parse tree produced by DustParser#return_statment.
    def enterReturn_statment(self, ctx:DustParser.Return_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#return_statment.
    def exitReturn_statment(self, ctx:DustParser.Return_statmentContext):
        pass


    # Enter a parse tree produced by DustParser#condition_list.
    def enterCondition_list(self, ctx:DustParser.Condition_listContext):
        pass

    # Exit a parse tree produced by DustParser#condition_list.
    def exitCondition_list(self, ctx:DustParser.Condition_listContext):
        pass


    # Enter a parse tree produced by DustParser#condition.
    def enterCondition(self, ctx:DustParser.ConditionContext):
        pass

    # Exit a parse tree produced by DustParser#condition.
    def exitCondition(self, ctx:DustParser.ConditionContext):
        pass


    # Enter a parse tree produced by DustParser#if_statment.
    def enterIf_statment(self, ctx:DustParser.If_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#if_statment.
    def exitIf_statment(self, ctx:DustParser.If_statmentContext):
        pass


    # Enter a parse tree produced by DustParser#while_statment.
    def enterWhile_statment(self, ctx:DustParser.While_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#while_statment.
    def exitWhile_statment(self, ctx:DustParser.While_statmentContext):
        pass


    # Enter a parse tree produced by DustParser#if_else_statment.
    def enterIf_else_statment(self, ctx:DustParser.If_else_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#if_else_statment.
    def exitIf_else_statment(self, ctx:DustParser.If_else_statmentContext):
        pass


    # Enter a parse tree produced by DustParser#print_statment.
    def enterPrint_statment(self, ctx:DustParser.Print_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#print_statment.
    def exitPrint_statment(self, ctx:DustParser.Print_statmentContext):
        pass


    # Enter a parse tree produced by DustParser#for_statment.
    def enterFor_statment(self, ctx:DustParser.For_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#for_statment.
    def exitFor_statment(self, ctx:DustParser.For_statmentContext):
        pass


    # Enter a parse tree produced by DustParser#method_call.
    def enterMethod_call(self, ctx:DustParser.Method_callContext):
        pass

    # Exit a parse tree produced by DustParser#method_call.
    def exitMethod_call(self, ctx:DustParser.Method_callContext):
        pass


    # Enter a parse tree produced by DustParser#assignment.
    def enterAssignment(self, ctx:DustParser.AssignmentContext):
        pass

    # Exit a parse tree produced by DustParser#assignment.
    def exitAssignment(self, ctx:DustParser.AssignmentContext):
        pass


    # Enter a parse tree produced by DustParser#exp.
    def enterExp(self, ctx:DustParser.ExpContext):
        pass

    # Exit a parse tree produced by DustParser#exp.
    def exitExp(self, ctx:DustParser.ExpContext):
        pass


    # Enter a parse tree produced by DustParser#prefixexp.
    def enterPrefixexp(self, ctx:DustParser.PrefixexpContext):
        pass

    # Exit a parse tree produced by DustParser#prefixexp.
    def exitPrefixexp(self, ctx:DustParser.PrefixexpContext):
        pass


    # Enter a parse tree produced by DustParser#args.
    def enterArgs(self, ctx:DustParser.ArgsContext):
        pass

    # Exit a parse tree produced by DustParser#args.
    def exitArgs(self, ctx:DustParser.ArgsContext):
        pass


    # Enter a parse tree produced by DustParser#explist.
    def enterExplist(self, ctx:DustParser.ExplistContext):
        pass

    # Exit a parse tree produced by DustParser#explist.
    def exitExplist(self, ctx:DustParser.ExplistContext):
        pass


    # Enter a parse tree produced by DustParser#arithmetic_operator.
    def enterArithmetic_operator(self, ctx:DustParser.Arithmetic_operatorContext):
        pass

    # Exit a parse tree produced by DustParser#arithmetic_operator.
    def exitArithmetic_operator(self, ctx:DustParser.Arithmetic_operatorContext):
        pass


    # Enter a parse tree produced by DustParser#relational_operators.
    def enterRelational_operators(self, ctx:DustParser.Relational_operatorsContext):
        pass

    # Exit a parse tree produced by DustParser#relational_operators.
    def exitRelational_operators(self, ctx:DustParser.Relational_operatorsContext):
        pass


    # Enter a parse tree produced by DustParser#assignment_operators.
    def enterAssignment_operators(self, ctx:DustParser.Assignment_operatorsContext):
        pass

    # Exit a parse tree produced by DustParser#assignment_operators.
    def exitAssignment_operators(self, ctx:DustParser.Assignment_operatorsContext):
        pass



del DustParser