<?php
session_start();

if (isset($_SESSION["doctor"])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $workdays = $_POST["workdays"];
        // ذخیره روزهای کاری در پایگاه داده
        echo "روزهای کاری با موفقیت ثبت شدند!";
    }
} else {
    header("Location: login.php");
    exit();
}
?>
