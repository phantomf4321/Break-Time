<?php
session_start();

// حذف جلسه پزشک و بازگشت به صفحه ورود
session_destroy();
header("Location: login.php");
exit();
?>