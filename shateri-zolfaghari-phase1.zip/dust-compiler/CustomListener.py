from parser import DustListener
from parser import DustParser


class KeyPrinter(DustListener):
    indent_level = 0

    def print(self, message, **kwargs):
        for _ in range(self.indent_level):
            print("\t", end="")
        print(message, **kwargs)

    def indent(self):
        self.indent_level += 1

    def unindent(self):
        self.indent_level -= 1

    def enterProgram(self, ctx: DustParser.ProgramContext):
        self.print("program start {")
        self.indent()

    # Exit a parse tree produced by DustParser#program.
    def exitProgram(self, ctx: DustParser.ProgramContext):
        self.unindent()
        self.print("}")

    # Enter a parse tree produced by DustParser#importclass.
    def enterImportclass(self, ctx: DustParser.ImportclassContext):
        className = ctx.getChild(1).getText()
        self.print("import class: {}".format(className))

    # Enter a parse tree produced by DustParser#classDef.
    def enterClassDef(self, ctx: DustParser.ClassDefContext):
        className = ctx.getChild(1).getText()
        self.print("class: {}/ class parents: ".format(className), end="")
        parents = ""
        i = 3
        while ctx.getChild(i).getText() != ")":
            parents += ctx.getChild(i).getText()
            i += 1

        for p in parents.split(","):
            print("{}, ".format(p), end="")

        print("objects, {")
        self.indent()

    # Exit a parse tree produced by DustParser#classDef.
    def exitClassDef(self, ctx: DustParser.ClassDefContext):
        self.unindent()
        self.print("}")

    # Enter a parse tree produced by DustParser#varDec.
    def enterVarDec(self, ctx: DustParser.VarDecContext):
        self.print(
            "field: {}/ type={} ".format(
                ctx.getChild(1).getText(),
                ctx.getChild(0).getText(),
            )
        )

    # Enter a parse tree produced by DustParser#arrayDec.
    def enterArrayDec(self, ctx: DustParser.ArrayDecContext):
        self.print(
            "field: {}/ type={}".format(
                ctx.getChild(4).getText(), ctx.getChild(0).getText()
            )
        )

    # Enter a parse tree produced by DustParser#methodDec.
    def enterMethodDec(self, ctx: DustParser.MethodDecContext):
        self.print(
            "class method: {}/ return type: {} ".format(
                ctx.getChild(2).getText(), ctx.getChild(1).getText()
            ),
            end="",
        )
        print("{")
        pl = []
        if ctx.getChild(4).getText() != ")":
            p = ctx.getChild(4)
            for pp in p.getChildren():
                if pp.getText() != ",":
                    pl.append(
                        "{} {}".format(
                            pp.getChild(0).getText(), pp.getChild(1).getText()
                        )
                    )

        self.indent()
        self.print("parameter list: {}".format(pl))

    # Exit a parse tree produced by DustParser#methodDec.
    def exitMethodDec(self, ctx: DustParser.MethodDecContext):
        self.unindent()
        self.print("}")

    # Enter a parse tree produced by DustParser#constructor.
    def enterConstructor(self, ctx: DustParser.ConstructorContext):
        self.print("class constructor {} ".format(ctx.getChild(1).getText()), end="")
        print("{")
        pl = []
        if ctx.getChild(3).getText() != ")":
            p = ctx.getChild(3)
            for pp in p.getChildren():
                if pp.getText() != ",":
                    pl.append(
                        "{} {}".format(
                            pp.getChild(0).getText(), pp.getChild(1).getText()
                        )
                    )

        self.indent()
        self.print("parameter list: {}".format(pl))

    # Exit a parse tree produced by DustParser#constructor.
    def exitConstructor(self, ctx: DustParser.ConstructorContext):
        self.unindent()
        self.print("}")

    # Enter a parse tree produced by DustParser#condition_list.
    def enterCondition_list(self, ctx: DustParser.Condition_listContext):
        pass

    # Exit a parse tree produced by DustParser#condition_list.
    def exitCondition_list(self, ctx: DustParser.Condition_listContext):
        pass

    # Enter a parse tree produced by DustParser#condition.
    def enterCondition(self, ctx: DustParser.ConditionContext):
        pass

    # Exit a parse tree produced by DustParser#condition.
    def exitCondition(self, ctx: DustParser.ConditionContext):
        pass

    # Enter a parse tree produced by DustParser#if_statment.
    def enterIf_statment(self, ctx: DustParser.If_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#if_statment.
    def exitIf_statment(self, ctx: DustParser.If_statmentContext):
        pass

    # Enter a parse tree produced by DustParser#while_statment.
    def enterWhile_statment(self, ctx: DustParser.While_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#while_statment.
    def exitWhile_statment(self, ctx: DustParser.While_statmentContext):
        pass

    # Enter a parse tree produced by DustParser#if_else_statment.
    def enterIf_else_statment(self, ctx: DustParser.If_else_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#if_else_statment.
    def exitIf_else_statment(self, ctx: DustParser.If_else_statmentContext):
        pass

    # Enter a parse tree produced by DustParser#print_statment.
    def enterPrint_statment(self, ctx: DustParser.Print_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#print_statment.
    def exitPrint_statment(self, ctx: DustParser.Print_statmentContext):
        pass

    # Enter a parse tree produced by DustParser#for_statment.
    def enterFor_statment(self, ctx: DustParser.For_statmentContext):
        pass

    # Exit a parse tree produced by DustParser#for_statment.
    def exitFor_statment(self, ctx: DustParser.For_statmentContext):
        pass
