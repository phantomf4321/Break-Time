import sys
from antlr4 import *
from parser import DustLexer
from parser import DustParser
from CustomListener import KeyPrinter


def main(argv):
    input_stream = FileStream(argv[1])
    lexer = DustLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser2 = DustParser(stream)
    tree = parser2.program()
    printer = KeyPrinter()
    walker = ParseTreeWalker()
    walker.walk(printer, tree)


if __name__ == "__main__":
    main(sys.argv)
